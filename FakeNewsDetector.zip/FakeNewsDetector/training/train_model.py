"""
Train the fake-news classifier and export it for the Android app.

The app loads app/src/main/assets/model.json. The seed model that ships with the project is
hand-weighted so the app works out of the box. To get a model trained on real data:

1. Download the ISOT "Fake and Real News Dataset" from Kaggle. It contains Fake.csv and True.csv
   with the columns: title, text, subject, date.
2. pip install pandas scikit-learn
3. python training/train_model.py --fake path/to/Fake.csv --real path/to/True.csv

The script prints accuracy, precision, recall, F1 and the confusion matrix (use these for the
"Performance of model" section of the report) and overwrites the model file.

Notes
- Label 1 = fake, label 0 = real. The app reads positive weights as "pushes toward fake".
- Features: TF-IDF (unigrams, English stop words removed) -> logistic regression. The app repeats
  the same TF-IDF maths, so scores match between Python and Android.
- In ISOT, real articles start with a dateline such as "WASHINGTON (Reuters) - " and the word
  "Reuters" appears in many of them. A model can score ~99% just by learning that. This script
  removes those cues by default. Pass --keep-source-cues to leave them in.
- Style weights are left empty for a trained model, so the verdict comes only from the trained
  logistic regression. The indicator rows in the app are still computed from the text.
"""
import argparse
import json
import re
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split

DATELINE = re.compile(r"^.{0,80}?\((reuters|ap|afp)\)\s*[-–—]\s*", re.IGNORECASE)
SOURCE_WORD = re.compile(r"\b(reuters|associated press|afp)\b", re.IGNORECASE)
URL = re.compile(r"https?://\S+|www\.\S+")


def clean(text: str, keep_source_cues: bool) -> str:
    text = URL.sub(" ", str(text))
    if not keep_source_cues:
        text = DATELINE.sub("", text)
        text = SOURCE_WORD.sub(" ", text)
    return re.sub(r"\s+", " ", text).strip()


def load(fake_path: str, real_path: str, keep_source_cues: bool) -> pd.DataFrame:
    fake = pd.read_csv(fake_path)
    real = pd.read_csv(real_path)
    fake["label"] = 1
    real["label"] = 0
    df = pd.concat([fake, real], ignore_index=True)
    df["content"] = (df["title"].fillna("") + ". " + df["text"].fillna("")).map(
        lambda t: clean(t, keep_source_cues)
    )
    df = df[df["content"].str.split().str.len() >= 20]
    return df.drop_duplicates(subset="content").reset_index(drop=True)


def report(name, y_true, y_pred):
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred),
    }
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    print(f"\n{name}")
    for key, value in metrics.items():
        print(f"  {key:9s} {value:.4f}")
    print(f"  confusion matrix  TP={tp}  TN={tn}  FP={fp}  FN={fn}")
    return {k: round(float(v), 4) for k, v in metrics.items()} | {
        "tp": int(tp), "tn": int(tn), "fp": int(fp), "fn": int(fn)
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--fake", required=True, help="path to Fake.csv")
    parser.add_argument("--real", required=True, help="path to True.csv")
    parser.add_argument("--out", default="app/src/main/assets/model.json")
    parser.add_argument("--max-features", type=int, default=20000)
    parser.add_argument("--min-df", type=int, default=5)
    parser.add_argument("--C", type=float, default=1.0, help="inverse regularisation strength")
    parser.add_argument("--keep-source-cues", action="store_true")
    parser.add_argument("--compare", action="store_true", help="also report Naive Bayes and linear SVM")
    args = parser.parse_args()

    df = load(args.fake, args.real, args.keep_source_cues)
    print(f"{len(df)} articles after cleaning ({int(df.label.sum())} fake, {int((1 - df.label).sum())} real)")

    x_train, x_test, y_train, y_test = train_test_split(
        df["content"], df["label"], test_size=0.2, random_state=42, stratify=df["label"]
    )

    vectorizer = TfidfVectorizer(
        lowercase=True,
        stop_words="english",
        token_pattern=r"(?u)\b\w\w+\b",
        max_features=args.max_features,
        min_df=args.min_df,
        max_df=0.8,
    )
    train_matrix = vectorizer.fit_transform(x_train)
    test_matrix = vectorizer.transform(x_test)

    model = LogisticRegression(max_iter=1000, C=args.C)
    model.fit(train_matrix, y_train)
    metrics = report("Logistic regression (exported)", y_test, model.predict(test_matrix))

    if args.compare:
        from sklearn.naive_bayes import MultinomialNB
        from sklearn.svm import LinearSVC
        report("Multinomial Naive Bayes", y_test, MultinomialNB().fit(train_matrix, y_train).predict(test_matrix))
        report("Linear SVM", y_test, LinearSVC().fit(train_matrix, y_train).predict(test_matrix))

    terms = vectorizer.get_feature_names_out()
    vocab = {
        term: [round(float(idf), 6), round(float(weight), 6)]
        for term, idf, weight in zip(terms, vectorizer.idf_, model.coef_[0])
    }
    payload = {
        "name": "Logistic regression (TF-IDF), trained on ISOT",
        "bias": round(float(model.intercept_[0]), 6),
        "l2_normalize": True,
        "style_weights": {},
        "metrics": metrics,
        "vocab": vocab,
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    print(f"\nSaved {len(vocab)} terms to {out}")


if __name__ == "__main__":
    main()
