package com.fakenewsdetector.app

import com.fakenewsdetector.app.detector.FakeNewsClassifier
import com.fakenewsdetector.app.detector.Samples
import com.fakenewsdetector.app.detector.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ClassifierTest {

    // Unit tests run with the module directory as the working directory.
    private val classifier: FakeNewsClassifier by lazy {
        FakeNewsClassifier.fromJson(File("src/main/assets/model.json").readText())
    }

    @Test
    fun realSampleIsLikelyReal() {
        val result = classifier.analyze(Samples.real.text)
        assertEquals(Verdict.LIKELY_REAL, result.verdict)
        assertTrue(result.fakeProbability < 0.35)
    }

    @Test
    fun suspiciousSampleIsLikelyFake() {
        val result = classifier.analyze(Samples.suspicious.text)
        assertEquals(Verdict.LIKELY_FAKE, result.verdict)
        assertTrue(result.fakeProbability > 0.65)
    }

    @Test
    fun neutralTextIsUncertain() {
        val result = classifier.analyze(
            "The local football club will hold its annual meeting on the village green " +
                "and all members are invited to bring snacks."
        )
        assertEquals(Verdict.UNCERTAIN, result.verdict)
    }

    @Test
    fun veryShortTextIsRejected() {
        assertEquals(Verdict.TOO_SHORT, classifier.analyze("Hello there friend").verdict)
    }
}
