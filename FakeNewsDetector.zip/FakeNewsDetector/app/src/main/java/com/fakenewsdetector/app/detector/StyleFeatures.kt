package com.fakenewsdetector.app.detector

/**
 * Writing-style signals that are known to differ between sensational and factual reporting.
 * Every value is scaled to 0..1 so it can be weighted by the logistic regression.
 */
internal data class StyleFeatures(
    val exclamation: Double,
    val caps: Double,
    val clickbait: Double,
    val anonymous: Double,
    val absolutist: Double,
    val emotive: Double,
    val credible: Double,
    val dateNumber: Double,
    val attributedQuote: Double,
    /** Raw number of distinct credibility cues found (institutions, "according to", ...). */
    val credibleHits: Int
) {
    fun asMap(): Map<String, Double> = mapOf(
        "exclamation" to exclamation,
        "caps" to caps,
        "clickbait" to clickbait,
        "anonymous" to anonymous,
        "absolutist" to absolutist,
        "emotive" to emotive,
        "credible" to credible,
        "date_number" to dateNumber,
        "attributed_quote" to attributedQuote
    )

    companion object {
        private fun phrases(vararg items: String): List<Regex> =
            items.map { Regex("\\b" + Regex.escape(it) + "\\b") }

        private val CLICKBAIT = phrases(
            "breaking", "shocking", "share before", "share this", "before they delete",
            "they don't want you to know", "you won't believe", "wake up", "exposed",
            "bombshell", "100% proven", "doctors hate", "mainstream media", "must see",
            "go viral", "urgent", "secret", "secretly", "leaked"
        )
        private val ANONYMOUS = phrases(
            "anonymous", "anonymous sources", "unnamed", "insiders", "insider", "sources reveal"
        )
        private val ABSOLUTIST = phrases(
            "forever", "destroy", "everyone", "nobody", "never", "always", "totally",
            "guaranteed", "completely", "will end"
        )
        private val EMOTIVE = phrases(
            "outrage", "terrifying", "horrifying", "disgusting", "evil", "traitor", "traitors",
            "devastating", "shocking", "unbelievable", "insane", "catastrophe", "panic", "disaster"
        )
        private val CREDIBLE = phrases(
            "according to", "reuters", "associated press", "bbc", "said in a statement",
            "spokesperson", "spokesman", "spokeswoman", "officials", "ministry", "federal reserve",
            "department of", "announced", "researchers", "published in", "statement",
            "university", "committee", "agency", "commission", "percent", "parliament",
            "senate", "court", "reported"
        )
        private val SAID = Regex("\\b(said|says|told|according to)\\b")
        private val CAPS_WORD = Regex("\\b[A-Z]{3,}\\b")
        private val DATE_OR_NUMBER = Regex(
            "\\d|\\b(january|february|march|april|june|july|august|september|october|november|" +
                "december|monday|tuesday|wednesday|thursday|friday|saturday|sunday|" +
                "next (week|month|year)|last (week|month|year)|yesterday|today)\\b"
        )
        private val ACRONYMS = setOf(
            "FBI", "CIA", "NASA", "WHO", "CNN", "BBC", "GDP", "CEO", "NATO", "COVID",
            "NHS", "USA", "EU", "UN", "IMF", "AFP", "NGO", "CBN", "INEC"
        )

        fun extract(text: String, lower: String, wordCount: Int): StyleFeatures {
            val exclamations = text.count { it == '!' }
            val capsWords = CAPS_WORD.findAll(text).count { it.value !in ACRONYMS }
            val capsRatio = capsWords.toDouble() / wordCount.coerceAtLeast(1)
            val credibleHits = CREDIBLE.count { it.containsMatchIn(lower) }
            val hasQuote = text.contains('"') || text.contains('“')
            val hasAttribution = SAID.containsMatchIn(lower)

            return StyleFeatures(
                exclamation = (exclamations / 3.0).coerceAtMost(1.0),
                caps = (capsRatio * 10.0).coerceAtMost(1.0),
                clickbait = (CLICKBAIT.count { it.containsMatchIn(lower) } / 2.0).coerceAtMost(1.0),
                anonymous = ANONYMOUS.count { it.containsMatchIn(lower) }.toDouble().coerceAtMost(1.0),
                absolutist = (ABSOLUTIST.count { it.containsMatchIn(lower) } / 2.0).coerceAtMost(1.0),
                emotive = (EMOTIVE.count { it.containsMatchIn(lower) } / 2.0).coerceAtMost(1.0),
                credible = (credibleHits / 3.0).coerceAtMost(1.0),
                dateNumber = if (DATE_OR_NUMBER.containsMatchIn(lower)) 1.0 else 0.0,
                attributedQuote = if (hasQuote && hasAttribution) 1.0 else 0.0,
                credibleHits = credibleHits
            )
        }
    }
}
