package com.fakenewsdetector.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fakenewsdetector.app.detector.AnalysisResult
import com.fakenewsdetector.app.detector.FakeNewsClassifier
import com.fakenewsdetector.app.detector.HistoryEntry
import com.fakenewsdetector.app.detector.HistoryStore
import com.fakenewsdetector.app.detector.Sample
import com.fakenewsdetector.app.detector.Verdict
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetectorViewModel(application: Application) : AndroidViewModel(application) {

    // Loaded on first use, on the background dispatcher (see analyze()).
    private val classifier: FakeNewsClassifier by lazy {
        FakeNewsClassifier.fromAssets(getApplication<Application>())
    }

    private val store = HistoryStore(application)

    var history by mutableStateOf(store.load())
        private set

    var input by mutableStateOf("")
        private set

    var result by mutableStateOf<AnalysisResult?>(null)
        private set

    var isAnalyzing by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    fun onInputChange(text: String) {
        input = text
        // The old result describes the old text, so hide it once the text changes.
        if (result != null) result = null
        errorMessage = null
    }

    fun clear() {
        input = ""
        result = null
        errorMessage = null
    }

    fun openHistory(entry: HistoryEntry) {
        input = entry.text
        analyze()
    }

    fun clearHistory() {
        history = emptyList()
        store.save(history)
    }

    private fun record(text: String, analysis: AnalysisResult) {
        if (analysis.verdict == Verdict.TOO_SHORT) return
        val entry = HistoryEntry(
            text = text.take(MAX_SAVED_CHARS),
            verdict = analysis.verdict,
            fakeProbability = analysis.fakeProbability,
            timestamp = System.currentTimeMillis()
        )
        // Newest first, and a repeated text moves to the top instead of appearing twice.
        history = (listOf(entry) + history.filter { it.text != entry.text }).take(MAX_HISTORY)
        store.save(history)
    }

    fun useSample(sample: Sample) {
        input = sample.text
        analyze()
    }

    private companion object {
        const val MAX_HISTORY = 20
        const val MAX_SAVED_CHARS = 2000
    }

    fun analyze() {
        val text = input
        if (text.isBlank() || isAnalyzing) return
        isAnalyzing = true
        errorMessage = null
        viewModelScope.launch {
            try {
                val analysis = withContext(Dispatchers.Default) { classifier.analyze(text) }
                result = analysis
                record(text, analysis)
            } catch (e: Throwable) {
                // Throwable, not Exception, so a failure while loading the model shows a message
                // instead of closing the app.
                errorMessage = "The analysis failed: ${e.javaClass.simpleName}. ${e.message.orEmpty()}".trim()
            } finally {
                isAnalyzing = false
            }
        }
    }
}
