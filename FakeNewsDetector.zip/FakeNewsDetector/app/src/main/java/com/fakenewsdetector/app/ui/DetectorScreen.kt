package com.fakenewsdetector.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fakenewsdetector.app.detector.AnalysisResult
import com.fakenewsdetector.app.detector.FakeNewsClassifier
import com.fakenewsdetector.app.detector.HistoryEntry
import com.fakenewsdetector.app.detector.Level
import com.fakenewsdetector.app.detector.Sample
import com.fakenewsdetector.app.detector.Samples
import com.fakenewsdetector.app.detector.Verdict
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun DetectorScreen(vm: DetectorViewModel = viewModel()) {
    val focusManager = LocalFocusManager.current
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val resultRequester = remember { BringIntoViewRequester() }
    val result = vm.result

    // Bring the result into view once it has been laid out.
    LaunchedEffect(result) {
        if (result != null) {
            delay(150)
            resultRequester.bringIntoView()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Header()

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel("Test with sample news")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SampleCard(Samples.real, Modifier.weight(1f)) {
                    focusManager.clearFocus()
                    vm.useSample(it)
                }
                SampleCard(Samples.suspicious, Modifier.weight(1f)) {
                    focusManager.clearFocus()
                    vm.useSample(it)
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionLabel("News content")
            OutlinedTextField(
                value = vm.input,
                onValueChange = vm::onInputChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 160.dp),
                placeholder = { Text("Paste a news article, social media post or any news text here") },
                minLines = 6,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            val words = remember(vm.input) {
                vm.input.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (words == 1) "1 word" else "$words words",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    TextButton(onClick = {
                        val pasted = clipboard.getText()?.text
                        if (!pasted.isNullOrBlank()) vm.onInputChange(pasted)
                    }) { Text("Paste") }
                    TextButton(
                        onClick = { vm.clear() },
                        enabled = vm.input.isNotEmpty()
                    ) { Text("Clear") }
                }
            }
            Button(
                onClick = {
                    focusManager.clearFocus()
                    vm.analyze()
                },
                enabled = vm.input.isNotBlank() && !vm.isAnalyzing,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 14.dp)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (vm.isAnalyzing) "Analyzing..." else "Analyze for fake news",
                    style = MaterialTheme.typography.titleSmall
                )
            }
            vm.errorMessage?.let {
                Text(it, color = LocalStatusColors.current.bad, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (result != null) {
            ResultSection(
                result = result,
                onShare = { shareResult(context, result) },
                modifier = Modifier.bringIntoViewRequester(resultRequester)
            )
        }

        HistorySection(
            history = vm.history,
            onOpen = {
                focusManager.clearFocus()
                vm.openHistory(it)
            },
            onClear = vm::clearHistory
        )

        HowItWorks()

        Text(
            text = "Everything runs on your device and nothing you paste is sent anywhere. " +
                "A result is an estimate from a text model, not a fact-check.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun Header() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = "ON-DEVICE MACHINE LEARNING",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.2.sp
        )
        Text(
            text = "Fake News Detector",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Checks news text for the language and structure patterns that separate fabricated stories from factual reporting.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SampleCard(sample: Sample, modifier: Modifier = Modifier, onPick: (Sample) -> Unit) {
    val status = LocalStatusColors.current
    val tagColor = if (sample.looksReal) status.good else status.bad
    Card(
        onClick = { onPick(sample) },
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = sample.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = sample.text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Pill(sample.tag, tagColor)
        }
    }
}

@Composable
private fun Pill(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.14f), shape = RoundedCornerShape(50)) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

private class VerdictStyle(val label: String, val level: Level, val icon: ImageVector)

private fun verdictStyle(verdict: Verdict): VerdictStyle = when (verdict) {
    Verdict.LIKELY_REAL -> VerdictStyle("LIKELY REAL", Level.GOOD, Icons.Filled.CheckCircle)
    Verdict.LIKELY_FAKE -> VerdictStyle("LIKELY FAKE", Level.BAD, Icons.Filled.Warning)
    Verdict.UNCERTAIN -> VerdictStyle("UNCERTAIN", Level.WARN, Icons.Filled.Info)
    Verdict.TOO_SHORT -> VerdictStyle("TOO SHORT", Level.NEUTRAL, Icons.Filled.Info)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ResultSection(
    result: AnalysisResult,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val status = LocalStatusColors.current

    if (result.verdict == Verdict.TOO_SHORT) {
        Panel(modifier) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Info, contentDescription = null, tint = status.neutral)
                Text(
                    text = "Add a little more text. At least ${FakeNewsClassifier.MIN_WORDS} words " +
                        "are needed for a useful check, and you entered ${result.wordCount}.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    val style = verdictStyle(result.verdict)
    val verdictColor = status.forLevel(style.level)
    val fraction by animateFloatAsState(
        targetValue = result.realProbability.toFloat().coerceIn(0.03f, 1f),
        label = "credibility"
    )
    val fakePercent = (result.fakeProbability * 100).roundToInt()

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(style.icon, contentDescription = null, tint = verdictColor)
                Text(
                    text = "Analysis results",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Credibility assessment",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = style.label,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = verdictColor
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(50))
                            .background(verdictColor)
                    )
                }
                Text(
                    text = "Fake probability $fakePercent%  ·  ${result.wordCount} words analyzed",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Panel {
            SectionLabel("Detection indicators")
            result.indicators.forEachIndexed { index, indicator ->
                if (index > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = indicator.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = indicator.value,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = status.forLevel(indicator.level)
                    )
                }
            }
        }

        if (result.signals.isNotEmpty()) {
            Panel {
                SectionLabel("What influenced this result")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    result.signals.forEach { signal ->
                        Pill(signal.label, if (signal.towardFake) status.bad else status.good)
                    }
                }
                Text(
                    text = "Red pushed the score toward fake, green toward real.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Panel {
            SectionLabel("Recommendations")
            result.recommendations.forEach { line ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("•", color = verdictColor, style = MaterialTheme.typography.bodyMedium)
                    Text(line, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Model: ${result.modelName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onShare) { Text("Share result") }
            }
        }
    }
}

private fun shareResult(context: Context, result: AnalysisResult) {
    val verdict = verdictStyle(result.verdict).label
    val percent = (result.fakeProbability * 100).roundToInt()
    val message = "Fake News Detector: $verdict (fake probability $percent%). " +
        "This is an automated estimate, so check important claims with trusted sources."
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
    }
    context.startActivity(Intent.createChooser(send, "Share result"))
}

@Composable
private fun HistorySection(
    history: List<HistoryEntry>,
    onOpen: (HistoryEntry) -> Unit,
    onClear: () -> Unit
) {
    if (history.isEmpty()) return
    val status = LocalStatusColors.current

    Panel {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionLabel("Recent checks")
            TextButton(onClick = onClear) { Text("Clear") }
        }
        history.take(8).forEachIndexed { index, entry ->
            if (index > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            val (label, color) = when (entry.verdict) {
                Verdict.LIKELY_REAL -> "Real" to status.good
                Verdict.LIKELY_FAKE -> "Fake" to status.bad
                else -> "Unsure" to status.warn
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onOpen(entry) }
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Pill(label, color)
                Text(
                    text = entry.text,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Text(
            text = "Saved on this device only. Tap a check to open it again.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HowItWorks() {
    val items = listOf(
        "Language analysis" to "flags sensational wording, exclamation marks and capitalised words common in fake news.",
        "Source verification" to "looks for named institutions and attributed quotes, and for anonymous sourcing.",
        "Context awareness" to "checks for absolute claims and emotive wording meant to provoke a reaction.",
        "Structural analysis" to "looks for dates, figures and quotes that factual reporting usually contains.",
        "Pattern recognition" to "a TF-IDF logistic regression model scores the vocabulary of the text."
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "How this works",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
        )
        items.forEach { (title, body) ->
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(title) }
                    append(": ")
                    append(body)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
