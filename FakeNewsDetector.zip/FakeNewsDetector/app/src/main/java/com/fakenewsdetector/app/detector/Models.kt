package com.fakenewsdetector.app.detector

enum class Verdict { LIKELY_REAL, UNCERTAIN, LIKELY_FAKE, TOO_SHORT }

/** How an indicator should be coloured in the UI. */
enum class Level { GOOD, NEUTRAL, WARN, BAD }

data class Indicator(val label: String, val value: String, val level: Level)

/** A reason shown to the user. [towardFake] true means it pushed the score toward "fake". */
data class Signal(val label: String, val towardFake: Boolean)

data class AnalysisResult(
    val verdict: Verdict,
    /** Probability from the logistic regression model that the text is fake, 0..1. */
    val fakeProbability: Double,
    val indicators: List<Indicator>,
    val signals: List<Signal>,
    val recommendations: List<String>,
    val wordCount: Int,
    val modelName: String
) {
    val realProbability: Double get() = 1.0 - fakeProbability
}

/** One saved check, kept on the device so the user can reopen it. */
data class HistoryEntry(
    val text: String,
    val verdict: Verdict,
    val fakeProbability: Double,
    val timestamp: Long
)

data class Sample(val title: String, val text: String, val tag: String, val looksReal: Boolean)

object Samples {
    val real = Sample(
        title = "Real sample",
        text = "The Federal Reserve has announced new monetary policies to stabilize the US dollar " +
            "exchange rate. The measures will take effect from next month and include adjustments " +
            "to interest rates and foreign exchange regulations.",
        tag = "Real news",
        looksReal = true
    )

    val suspicious = Sample(
        title = "Suspicious sample",
        text = "BREAKING: Government secretly plans to sell all oil reserves to foreign investors " +
            "next week! Anonymous sources reveal shocking documents. This will destroy our economy " +
            "forever! Share before they delete this post.",
        tag = "Suspicious",
        looksReal = false
    )
}
