package com.fakenewsdetector.app.detector

/**
 * Turns the raw features into the plain-language indicators, reasons and
 * recommendations shown on the result screen. None of this changes the verdict;
 * the verdict comes from the logistic regression in [FakeNewsClassifier].
 */
internal object Explainer {

    private fun band(score: Double): Level = when {
        score < 0.2 -> Level.GOOD
        score < 0.5 -> Level.WARN
        else -> Level.BAD
    }

    fun indicators(f: StyleFeatures, wordCount: Int): List<Indicator> {
        val languageLevel = band(0.4 * f.clickbait + 0.3 * f.exclamation + 0.3 * f.caps)
        val language = Indicator(
            "Suspicious language",
            when (languageLevel) {
                Level.GOOD -> "Low risk"
                Level.WARN -> "Medium risk"
                else -> "High risk"
            },
            languageLevel
        )

        val source = when {
            f.anonymous > 0.0 -> Indicator("Source credibility", "Questionable", Level.BAD)
            f.credibleHits >= 2 -> Indicator("Source credibility", "Credible", Level.GOOD)
            f.credibleHits == 1 -> Indicator("Source credibility", "Partly cited", Level.NEUTRAL)
            else -> Indicator("Source credibility", "Not cited", Level.WARN)
        }

        val emotionLevel = band(0.4 * f.exclamation + 0.3 * f.emotive + 0.3 * f.absolutist)
        val emotion = Indicator(
            "Emotional manipulation",
            when (emotionLevel) {
                Level.GOOD -> "Normal"
                Level.WARN -> "Elevated"
                else -> "High"
            },
            emotionLevel
        )

        val structurePoints =
            (if (f.dateNumber > 0.0) 1 else 0) +
                (if (f.attributedQuote > 0.0) 1 else 0) +
                (if (f.credibleHits >= 1) 1 else 0) +
                (if (f.credibleHits >= 2) 1 else 0) +
                (if (wordCount >= 40) 1 else 0)
        val structure = when {
            structurePoints >= 3 -> Indicator("Factual structure", "Strong", Level.GOOD)
            structurePoints == 2 -> Indicator("Factual structure", "Moderate", Level.NEUTRAL)
            else -> Indicator("Factual structure", "Weak", Level.WARN)
        }

        return listOf(language, source, emotion, structure)
    }

    fun signals(f: StyleFeatures, contributions: List<Pair<String, Double>>): List<Signal> {
        val out = ArrayList<Signal>()
        if (f.clickbait > 0.0) out.add(Signal("Sensational phrases", true))
        if (f.exclamation > 0.0) out.add(Signal("Exclamation marks", true))
        if (f.caps > 0.2) out.add(Signal("Capitalised words", true))
        if (f.anonymous > 0.0) out.add(Signal("Anonymous sourcing", true))
        if (f.absolutist > 0.0) out.add(Signal("Absolute claims", true))
        if (f.emotive > 0.0) out.add(Signal("Emotive wording", true))
        if (f.credibleHits > 0) out.add(Signal("Named institutions or sources", false))
        if (f.dateNumber > 0.0) out.add(Signal("Dates or figures", false))
        if (f.attributedQuote > 0.0) out.add(Signal("Attributed quotes", false))

        contributions.filter { it.second > 0.02 }
            .sortedByDescending { it.second }
            .take(3)
            .forEach { out.add(Signal("“${it.first}”", true)) }
        contributions.filter { it.second < -0.02 }
            .sortedBy { it.second }
            .take(3)
            .forEach { out.add(Signal("“${it.first}”", false)) }

        return out.take(10)
    }

    fun recommendations(verdict: Verdict, f: StyleFeatures): List<String> {
        val out = ArrayList<String>()
        when (verdict) {
            Verdict.LIKELY_FAKE -> {
                out.add("High risk of misinformation.")
                out.add("Verify with several trusted news sources before sharing.")
                out.add("Check official channels for the same announcement.")
            }
            Verdict.UNCERTAIN -> {
                out.add("The text shows mixed signals.")
                out.add("Find the original source and check its date.")
                out.add("Compare with a reputable outlet before sharing.")
            }
            Verdict.LIKELY_REAL -> {
                out.add("Appears credible.")
                out.add("Wording and structure look like factual reporting.")
                out.add("Still verify important claims.")
            }
            Verdict.TOO_SHORT -> Unit
        }
        if (f.anonymous > 0.0 && verdict != Verdict.LIKELY_REAL) {
            out.add("Anonymous sourcing cannot be checked.")
        }
        if ((f.clickbait > 0.0 || f.exclamation > 0.0) && verdict != Verdict.LIKELY_REAL) {
            out.add("Urgent, sensational wording is a common misinformation tactic.")
        }
        return out.take(5)
    }
}
