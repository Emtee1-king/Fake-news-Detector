package com.fakenewsdetector.app.detector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the recent checks in app-private storage. Nothing leaves the device. */
class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryEntry> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                HistoryEntry(
                    text = o.getString("text"),
                    verdict = Verdict.valueOf(o.getString("verdict")),
                    fakeProbability = o.getDouble("p"),
                    timestamp = o.getLong("t")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(entries: List<HistoryEntry>) {
        val array = JSONArray()
        for (entry in entries) {
            array.put(
                JSONObject()
                    .put("text", entry.text)
                    .put("verdict", entry.verdict.name)
                    .put("p", entry.fakeProbability)
                    .put("t", entry.timestamp)
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "entries"
    }
}
