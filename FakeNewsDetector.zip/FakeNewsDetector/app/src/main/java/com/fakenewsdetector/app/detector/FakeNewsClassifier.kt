package com.fakenewsdetector.app.detector

import android.content.Context
import org.json.JSONObject
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * On-device logistic regression text classifier.
 *
 *   z = bias + sum(weight[term] * tfidf[term]) + sum(styleWeight[f] * styleFeature[f])
 *   P(fake) = 1 / (1 + e^-z)
 *
 * The TF-IDF part mirrors scikit-learn's TfidfVectorizer (lowercase, `\b\w\w+\b` tokens,
 * raw term counts times IDF, L2 normalised), so a model trained with training/train_model.py
 * and exported to assets/model.json gives the same scores here as in Python.
 */
class FakeNewsClassifier private constructor(
    val modelName: String,
    private val bias: Double,
    private val l2Normalize: Boolean,
    private val styleWeights: Map<String, Double>,
    private val vocab: Map<String, TermEntry>
) {
    private class TermEntry(val idf: Double, val weight: Double)

    fun analyze(rawText: String): AnalysisResult {
        val text = rawText
            .replace('’', '\'')
            .replace('‘', '\'')
            .trim()
        val wordCount = text.split(WHITESPACE).count { it.isNotEmpty() }

        if (wordCount < MIN_WORDS) {
            return AnalysisResult(
                verdict = Verdict.TOO_SHORT,
                fakeProbability = 0.5,
                indicators = emptyList(),
                signals = emptyList(),
                recommendations = emptyList(),
                wordCount = wordCount,
                modelName = modelName
            )
        }

        val lower = text.lowercase()
        val style = StyleFeatures.extract(text, lower, wordCount)

        // Term counts for words the model knows.
        val counts = HashMap<String, Int>()
        for (match in TOKEN.findAll(lower)) {
            val token = match.value
            if (vocab.containsKey(token)) {
                counts[token] = (counts[token] ?: 0) + 1
            }
        }

        var sumSquares = 0.0
        for ((term, count) in counts) {
            val x = count * vocab.getValue(term).idf
            sumSquares += x * x
        }
        val norm = if (l2Normalize && sumSquares > 0.0) sqrt(sumSquares) else 1.0

        var z = bias
        val contributions = ArrayList<Pair<String, Double>>()
        for ((term, count) in counts) {
            val entry = vocab.getValue(term)
            val contribution = entry.weight * count * entry.idf / norm
            z += contribution
            contributions.add(term to contribution)
        }
        for ((name, value) in style.asMap()) {
            z += (styleWeights[name] ?: 0.0) * value
        }

        val pFake = 1.0 / (1.0 + exp(-z))
        val verdict = when {
            pFake >= FAKE_THRESHOLD -> Verdict.LIKELY_FAKE
            pFake <= REAL_THRESHOLD -> Verdict.LIKELY_REAL
            else -> Verdict.UNCERTAIN
        }

        return AnalysisResult(
            verdict = verdict,
            fakeProbability = pFake,
            indicators = Explainer.indicators(style, wordCount),
            signals = Explainer.signals(style, contributions),
            recommendations = Explainer.recommendations(verdict, style),
            wordCount = wordCount,
            modelName = modelName
        )
    }

    companion object {
        const val MIN_WORDS = 8
        const val FAKE_THRESHOLD = 0.65
        const val REAL_THRESHOLD = 0.35

        private val WHITESPACE = Regex("\\s+")
        // (?U) makes \w Unicode-aware, matching Python's default behaviour.
        private val TOKEN = Regex("(?U)\\b\\w\\w+\\b")

        fun fromAssets(context: Context, fileName: String = "model.json"): FakeNewsClassifier {
            val json = context.assets.open(fileName).bufferedReader().use { it.readText() }
            return fromJson(json)
        }

        fun fromJson(json: String): FakeNewsClassifier {
            val root = JSONObject(json)

            val styleWeights = HashMap<String, Double>()
            val styleJson = root.optJSONObject("style_weights")
            if (styleJson != null) {
                val keys = styleJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    styleWeights[key] = styleJson.getDouble(key)
                }
            }

            val vocab = HashMap<String, TermEntry>()
            val vocabJson = root.getJSONObject("vocab")
            val terms = vocabJson.keys()
            while (terms.hasNext()) {
                val term = terms.next()
                val pair = vocabJson.getJSONArray(term)
                vocab[term] = TermEntry(idf = pair.getDouble(0), weight = pair.getDouble(1))
            }

            return FakeNewsClassifier(
                modelName = root.optString("name", "Logistic regression"),
                bias = root.optDouble("bias", 0.0),
                l2Normalize = root.optBoolean("l2_normalize", true),
                styleWeights = styleWeights,
                vocab = vocab
            )
        }
    }
}
