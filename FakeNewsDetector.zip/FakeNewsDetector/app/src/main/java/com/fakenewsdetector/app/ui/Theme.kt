package com.fakenewsdetector.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.fakenewsdetector.app.detector.Level

/** Semantic colours for good / warning / bad states, kept separate from the brand blue. */
@Immutable
class StatusColors(
    val good: Color,
    val warn: Color,
    val bad: Color,
    val neutral: Color
) {
    fun forLevel(level: Level): Color = when (level) {
        Level.GOOD -> good
        Level.WARN -> warn
        Level.BAD -> bad
        Level.NEUTRAL -> neutral
    }
}

private val LightStatus = StatusColors(
    good = Color(0xFF15803D),
    warn = Color(0xFFB45309),
    bad = Color(0xFFB91C1C),
    neutral = Color(0xFF475569)
)

private val DarkStatus = StatusColors(
    good = Color(0xFF4ADE80),
    warn = Color(0xFFFBBF24),
    bad = Color(0xFFF87171),
    neutral = Color(0xFF94A3B8)
)

val LocalStatusColors = staticCompositionLocalOf { LightStatus }

private val LightColors = lightColorScheme(
    primary = Color(0xFF1E4FD6),
    onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE6EDF8),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFF94A3B8),
    outlineVariant = Color(0xFFD3DCEB)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF0A1F4D),
    background = Color(0xFF0B1220),
    onBackground = Color(0xFFE6EDF7),
    surface = Color(0xFF111A2E),
    onSurface = Color(0xFFE6EDF7),
    surfaceVariant = Color(0xFF1B2740),
    onSurfaceVariant = Color(0xFFA9B6CC),
    outline = Color(0xFF64748B),
    outlineVariant = Color(0xFF2C3A57)
)

@Composable
fun FakeNewsTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    CompositionLocalProvider(LocalStatusColors provides if (dark) DarkStatus else LightStatus) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            content = content
        )
    }
}
