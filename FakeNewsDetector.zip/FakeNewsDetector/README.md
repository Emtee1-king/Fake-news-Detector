# Fake News Detector (Android)

An Android app that classifies pasted news text as likely real, likely fake or uncertain. It follows
the project document: a TF-IDF + logistic regression model, a simple screen with sample news, a text
box, an analyze button, a credibility result, detection indicators, recommendations and a
"How this works" panel. It runs fully on the device and has no internet permission.

Stack: Kotlin, Jetpack Compose (Material 3), minSdk 24, targetSdk 34.

## Open it in Android Studio

1. Unzip the project and choose **File > Open**, then select the `FakeNewsDetector` folder.
2. Let Gradle sync. The first sync downloads Gradle 8.7 and the Android SDK 34 platform if they are
   missing. If Android Studio offers to upgrade the Android Gradle Plugin, you can accept.
3. Pick a device or emulator and press **Run**.
4. Optional: run the unit tests with `./gradlew :app:testDebugUnitTest`.

`gradle-wrapper.jar` is not included. Android Studio uses the Gradle version in
`gradle/wrapper/gradle-wrapper.properties` on its own. For the command line, run `gradle wrapper`
once, or use the Gradle that ships with Android Studio.

## Build the APK without a computer (GitHub Actions)

1. On github.com (phone browser is fine) create a free account and a new repository.
2. In the repository choose **Add file > Upload files** and upload `FakeNewsDetector.zip` as it is.
3. Choose **Add file > Create new file**, type the name `.github/workflows/build-apk.yml`, paste in the
   contents of the `build-apk.yml` file that came with the zip, and commit.
4. Open the **Actions** tab, pick **Build APK**, press **Run workflow** and wait about 5 to 10 minutes.
5. Open the finished run, download the **FakeNewsDetector-apk** artifact, unzip it, and open the `.apk`
   on your phone. Allow installs from your browser or file manager when Android asks.

The workflow unpacks the zip itself, so you do not need to upload the folders one by one.

## How it works

```
text -> lowercase + tokenise -> TF-IDF vector (vocabulary from model.json)
     -> z = bias + sum(weight * tfidf) + sum(styleWeight * styleFeature)
     -> P(fake) = 1 / (1 + e^-z)
     -> >= 0.65 likely fake, <= 0.35 likely real, otherwise uncertain
```

| File | Purpose |
| --- | --- |
| `detector/FakeNewsClassifier.kt` | Loads `model.json`, computes TF-IDF and the logistic regression score |
| `detector/StyleFeatures.kt` | Writing-style signals: exclamation marks, capitalised words, sensational phrases, anonymous sourcing, absolute claims, emotive words, credibility cues, dates, attributed quotes |
| `detector/Explainer.kt` | Turns the features into the four indicators, the reason chips and the recommendations |
| `detector/HistoryStore.kt` | Saves the last 20 checks in app-private storage (backup is off, nothing leaves the device) |
| `ui/DetectorScreen.kt` | The screen, including the recent-checks list and the Share result button |
| `assets/model.json` | Model: bias, style weights, and `term: [idf, weight]` for each vocabulary word |
| `training/train_model.py` | Trains a model on a labelled dataset and writes `model.json` |

## The model that ships with the project

`model.json` is a **seed model with hand-set weights** (about 130 terms plus the style weights). It
makes the app work out of the box and gives sensible results on the two sample texts, but it has not
been trained or evaluated on a dataset. Do not quote accuracy figures for it.

To train a real model:

```
pip install pandas scikit-learn
python training/train_model.py --fake path/to/Fake.csv --real path/to/True.csv
```

Use the ISOT "Fake and Real News Dataset" from Kaggle (`Fake.csv` and `True.csv`). The script prints
accuracy, precision, recall, F1 and the confusion matrix on a held-out 20% split (`--compare` also
reports Naive Bayes and a linear SVM) and overwrites `app/src/main/assets/model.json`. Rebuild the
app afterwards. The script removes the "(Reuters)" dateline and the word "Reuters" by default,
because otherwise the model learns the publisher instead of the writing.

## Limits

- English text only, and text only. No images, video or links.
- It looks at wording and structure. It does not check facts or look up the publisher.
- Satire and borderline articles are hard cases for any text-only model.
- A result is an estimate, so the app tells people to verify important claims.
